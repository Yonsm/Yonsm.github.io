



////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
// Ԥ����
#include "MemFile.h"
////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////



////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
// ���캯��
CMemFile::CMemFile(PCTSTR ptzPath, BOOL bReadOnly, DWORD dwStart, DWORD dwSize)
{
	m_hMapping = NULL;
	m_pvFile = NULL;
	m_dwSize = 0;

	m_hFile = CreateFile(ptzPath, bReadOnly ? GENERIC_READ : (GENERIC_READ | GENERIC_WRITE), 
		0, NULL, OPEN_EXISTING, FILE_ATTRIBUTE_NORMAL, NULL);
	if (m_hFile != INVALID_HANDLE_VALUE)
	{
		m_dwSize = dwSize;
		if ((m_dwSize != 0) || (m_dwSize == -1))
		{
			m_dwSize = GetFileSize(m_hFile, NULL);
			if (m_dwSize <= dwStart)
			{
				return;
			}
			m_dwSize -= dwStart;
		}

		if ((m_dwSize != 0) && (m_dwSize != INVALID_FILE_SIZE))
		{
			if (bReadOnly)
			{
				m_pvFile = new BYTE[m_dwSize + 10240];
				if (m_pvFile)
				{
					if (dwStart)
					{
						SetFilePointer(m_hFile, dwStart, NULL, FILE_BEGIN);
					}
					ReadFile(m_hFile, m_pvFile, m_dwSize, &m_dwSize, NULL);
				}
			}
			else
			{
				m_hMapping = CreateFileMapping(m_hFile, NULL, PAGE_READWRITE, 0, m_dwSize, NULL);
				if (m_hMapping)
				{
					m_pvFile = MapViewOfFile(m_hMapping, FILE_MAP_ALL_ACCESS, 0, dwStart, m_dwSize);
				}
			}
		}
	}
}
////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////



////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
// ��������
CMemFile::~CMemFile()
{
	if (m_pvFile)
	{
		if (m_hMapping)
		{
			UnmapViewOfFile(m_pvFile);
		}
		else
		{
			delete[] m_pvFile;
		}
	}

	if (m_hMapping)
	{
		CloseHandle(m_hMapping);
	}

	if (m_hFile != INVALID_HANDLE_VALUE)
	{
		CloseHandle(m_hFile);
	}
}
////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
