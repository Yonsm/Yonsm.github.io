


////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
// Ԥ����
#include <TChar.h>
#include "Ini.h"
#include "Define.h"
#include "MemFile.h"
#include "Resource.h"
////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////



////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
// ��������
VOID OnCommand(HWND hWnd, WPARAM wParam);
UINT GetRecent(HWND hWnd, PTSTR ptzText);
UINT AltID(PCTSTR ptzPath, GUID &idSearch, GUID &idReplace, HWND hWnd);
UINT AltID(PCTSTR ptzPath, PCTSTR ptzSearch, PCTSTR ptzReplace, HWND hWnd);
INT_PTR CALLBACK MainDlgProc(HWND hWnd, UINT uMsg, WPARAM wParam, LPARAM lParam);
////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////



////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
// ��ں���
INT APIENTRY _tWinMain(HINSTANCE hInstance, HINSTANCE hPrevInstance, PTSTR ptzCmdLine, INT iCmdShow)
{
	return (INT) DialogBoxParam(hInstance, MAKEINTRESOURCE(IDD_Main), NULL, MainDlgProc, (LPARAM) ptzCmdLine);
}
////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////



////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
// �����ڻص�����
INT_PTR CALLBACK MainDlgProc(HWND hWnd, UINT uMsg, WPARAM wParam, LPARAM lParam)
{
	TCHAR tzPath[MAX_PATH];

	switch (uMsg)
	{
	case WM_INITDIALOG:
		SetDlgItemText(hWnd, IDC_Path, (PTSTR) lParam);
		SendDlgItemMessage(hWnd, IDC_Path, EM_LIMITTEXT, MAX_PATH, 0);
		SendDlgItemMessage(hWnd, IDC_Search, EM_LIMITTEXT, MAX_PATH, 0);
		SendDlgItemMessage(hWnd, IDC_Replace, EM_LIMITTEXT, MAX_PATH, 0);
		SetClassLongPtr(hWnd, GCLP_HICON, (LONG_PTR) LoadIcon(GetModuleHandle(NULL), MAKEINTRESOURCE(IDI_Main)));
		break;

	case WM_COMMAND:
		OnCommand(hWnd, wParam);
		break;

	case WM_DROPFILES:
		DragQueryFile((HDROP) wParam, 0, tzPath, MAX_PATH);
		DragFinish((HDROP) wParam);
		SetDlgItemText(hWnd, IDC_Path, tzPath);
		break;

	case WM_CLOSE:
		OnCommand(hWnd, IDC_Exit);
		break;
	}

	return FALSE;
}
////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////



////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
// ������Ϣ����
VOID OnCommand(HWND hWnd, WPARAM wParam)
{
	OPENFILENAME ofn = {0};
	TCHAR tzPath[MAX_PATH];
	TCHAR tzSearch[MAX_PATH];
	TCHAR tzReplace[MAX_PATH];

	switch (LOWORD(wParam))
	{
	case IDC_Browse:
		GetDlgItemText(hWnd, IDC_Path, tzPath, MAX_PATH);
		ofn.lStructSize = sizeof(OPENFILENAME);
		ofn.hwndOwner = hWnd;
		ofn.lpstrFile = tzPath;
		ofn.nMaxFile = MAX_PATH;
		ofn.lpstrDefExt = TEXT(".exe");
		ofn.lpstrFilter = TEXT("�����ļ� (*.*)\0*.*\0");
		ofn.Flags = OFN_ENABLESIZING | OFN_FILEMUSTEXIST | OFN_HIDEREADONLY;
		if (GetOpenFileName(&ofn))
		{
			SetDlgItemText(hWnd, IDC_Path, tzPath);
		}
		break;

	case IDC_Path:
	case IDC_Search:
	case IDC_Replace:
		if (HIWORD(wParam) == EN_CHANGE)
		{
			BOOL bEnable = 
				SendDlgItemMessage(hWnd, IDC_Path, WM_GETTEXTLENGTH, 0, 0) &&
				SendDlgItemMessage(hWnd, IDC_Search, WM_GETTEXTLENGTH, 0, 0) &&
				SendDlgItemMessage(hWnd, IDC_Replace, WM_GETTEXTLENGTH, 0, 0);
			EnableWindow(GetDlgItem(hWnd, IDC_Execute), bEnable);
		}
		break;

	case IDC_SList:
	case IDC_RList:
		if (GetRecent(GetDlgItem(hWnd, LOWORD(wParam)), tzSearch))
		{
			SetDlgItemText(hWnd, (LOWORD(wParam) == IDC_SList) ? IDC_Search : IDC_Replace, tzSearch);
		}
		break;

	case IDC_Execute:
		GetDlgItemText(hWnd, IDC_Path, tzPath, MAX_PATH);
		GetDlgItemText(hWnd, IDC_Search, tzSearch, MAX_PATH);
		GetDlgItemText(hWnd, IDC_Replace, tzReplace, MAX_PATH);
		AltID(tzPath, tzSearch, tzReplace, hWnd);
		break;

	case IDC_About:
		MessageBox(hWnd, 
			TEXT("AltID - ȫ��Ψһ��ʶ�滻����\n\n")
			TEXT("  �汾 ") STR_VersionStamp TEXT(" ") STR_BuildStamp TEXT("\n\n")
			TEXT("  ��Ȩ���� (C) 2006 Yonsm.NET����������Ȩ��"), 
			STR_AppName, MB_ICONINFORMATION);
		break;

	case IDC_Exit:
		EndDialog(hWnd, 0);
		break;
	}
}
////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////



////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
// �滻ȫ��Ψһ��ʶ
UINT AltID(PCTSTR ptzPath, GUID &idSearch, GUID &idReplace, HWND hWnd)
{
	UINT uResult = 0;
	CMemFile mf(ptzPath);
	DWORD dwSize = mf;
	if (dwSize >= sizeof(GUID))
	{
		PBYTE pbFile = (PBYTE) ((PVOID) mf);
		PBYTE pbEnd = pbFile + (DWORD) mf - sizeof(GUID) + 1;
		
		for (PBYTE p = pbFile; p < pbEnd; p++)
		{
			if (*((LPGUID) p) == idSearch)
			{
				TCHAR tzText[MAX_PATH];
				wsprintf(tzText, TEXT("���ļ�ƫ�� %08X ���ҵ���ʶ���Ƿ�Ҫ�滻?"), p - pbFile);
				UINT i = MessageBox(hWnd, tzText, STR_AppName, MB_ICONQUESTION | MB_YESNOCANCEL);
				if (i == IDYES)
				{
					uResult++;
					*((LPGUID) p) = idReplace;
				}
				else if (i == IDCANCEL)
				{
					break;
				}
			}
		}
	}

	return uResult;
}
////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////



////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
// �滻ȫ��Ψһ��ʶ
UINT AltID(PCTSTR ptzPath, PCTSTR ptzSearch, PCTSTR ptzReplace, HWND hWnd)
{
	GUID idSearch;
	GUID idReplace;
	TCHAR tzSearch[MAX_PATH];
	TCHAR tzReplace[MAX_PATH];

	if (ptzSearch[0] == '{')
	{
		lstrcpy(tzSearch, ptzSearch);
	}
	else
	{
		wsprintf(tzSearch,TEXT("{%s}"), ptzSearch);
	}

	if (ptzReplace[0] == '{')
	{
		lstrcpy(tzReplace, ptzReplace);
	}
	else
	{
		wsprintf(tzReplace,TEXT("{%s}"), ptzReplace);
	}

	if ((IIDFromString(tzSearch, &idSearch) == S_OK) &&
		(IIDFromString(tzReplace, &idReplace) == S_OK))
	{
		TCHAR tzText[MAX_PATH];
		CIni ini(NULL, TEXT("Recent"));
		ini.SetString(tzSearch, tzSearch);
		ini.SetString(tzReplace, tzReplace);
		wsprintf(tzText, TEXT("�滻�� %u ����"), AltID(ptzPath, idSearch, idReplace, hWnd));
		return MessageBox(hWnd, tzText, STR_AppName, MB_ICONINFORMATION);
	}
	else
	{
		return MessageBox(hWnd, TEXT("��ʶ��ʽ���󣬱���Ϊ {XXXXXXXX-XXXX-XXXX-XXXX-XXXXXXXXXXXX} ��ʽ��"), STR_AppName, MB_ICONSTOP);
	}
}
////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////



////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
// ��ȡ�½���ʶ
UINT GetRecent(HWND hWnd, PTSTR ptzText)
{
	TCHAR tzBuffer[10240];
	CIni ini(NULL, TEXT("Recent"));
	if (ini.GetSection(tzBuffer, sizeof(tzBuffer)) == 0)
	{
		return 0;
	}

	UINT i = IDC_Recent;
	HMENU hMenu = CreatePopupMenu();
	for (PTSTR p = tzBuffer; *p; )
	{
		for (PTSTR q = p; *q; q++)
		{
			if (*q == '=')
			{
				*q++ = 0;
				if (*p == '-')
				{
					AppendMenu(hMenu, MF_SEPARATOR, 0, NULL);
				}
				else
				{
					AppendMenu(hMenu, MF_STRING, i++, p);
				}
				p = q + lstrlen(q) + 1;
				break;
			}
		}
	}

	RECT rtRect;
	GetWindowRect(hWnd, &rtRect);
	UINT uCmd = TrackPopupMenu(hMenu, TPM_LEFTALIGN | TPM_RETURNCMD, rtRect.right, rtRect.top, 0, hWnd, NULL);
	GetMenuString(hMenu, uCmd, tzBuffer, MAX_PATH, MF_BYCOMMAND);
	DestroyMenu(hMenu);

	return ini.GetString(tzBuffer, ptzText);
}
////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
