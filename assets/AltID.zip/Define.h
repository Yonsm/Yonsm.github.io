


////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
// Header.
#pragma once
#pragma warning(disable: 4163 4995 4996 4530 4244)

#include <Windows.h>
////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////



////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
// Version information.
#define _String(v)				#v
#define _DotJoin(a, b, c, d)	_String(a.b.c.d)

#define VER_Major				1
#define VER_Minor				0
#define VER_Release				3
#define VER_Build				14
#define VER_Version				MAKELONG(MAKEWORD(VER_Major, VER_Minor), VER_Release)
#define STR_Version				TEXT(_DotJoin(VER_Major, VER_Minor, VER_Release, VER_Build))

#if defined(_M_IA64)
#define STR_Architecture		"ia64"
#define STR_VersionStamp		STR_Version TEXT(" IA64")
#elif defined(_M_X64)
#define STR_Architecture		"amd64"
#define STR_VersionStamp		STR_Version TEXT(" X64")
#elif defined(_UNICODE)
#define STR_Architecture		"x86"
#define STR_VersionStamp		STR_Version TEXT(" X86U")
#else
#define STR_Architecture		"x86"
#define STR_VersionStamp		STR_Version TEXT(" X86")
#endif

#define STR_BuildDate			TEXT(__DATE__)
#define STR_BuildTime			TEXT(__TIME__)
#define STR_BuildStamp			TEXT(__DATE__) TEXT(" ") TEXT(__TIME__)
////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////



////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
// Program information.
#define STR_AppName				TEXT("AltID")
#define STR_FileName			STR_AppName TEXT(".exe")
#define STR_Description			TEXT("Alter GUID")

#define STR_Author				TEXT("Yonsm")
#define STR_Corporation			TEXT("Yonsm.NET")
#define STR_Web					TEXT("WWW.Yonsm.NET")
#define STR_WebUrl				TEXT("HTTP://WWW.Yonsm.NET")
#define STR_Comments			TEXT("Powered by ") STR_Author
#define STR_Copyright			TEXT("Copyright (C) 2006 ") STR_Corporation TEXT(". All rights reserved.")
////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
