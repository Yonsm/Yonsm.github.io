


////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
// Ԥ����
#pragma once
#include <Windows.h>
typedef LPCTSTR PCTSTR;
////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////



////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
// CIni ��
class CIni
{
public:
	// INI �ļ���
	 TCHAR m_tzIniName[MAX_PATH];

	// INI ����
	 PCTSTR m_ptzSecName;

public:
	inline CIni(PCTSTR ptzIniName = NULL, PCTSTR ptzSecName = TEXT("Main"))
	{
		if (ptzIniName)
		{
			lstrcpy(m_tzIniName, ptzIniName);
		}
		else
		{
			lstrcpy(m_tzIniName + GetModuleFileName(GetCurModule(), m_tzIniName, MAX_PATH) - 4, TEXT(".ini"));
		}
		m_ptzSecName = ptzSecName;
	}

public:
	// ���ý���
	inline  VOID SetSecName(PCTSTR ptzSecName = TEXT("Main"))
	{
		m_ptzSecName = ptzSecName;
	}

	static HMODULE GetCurModule()
	{
		MEMORY_BASIC_INFORMATION m = {0};
		VirtualQuery(GetCurModule, &m, sizeof(MEMORY_BASIC_INFORMATION));
		return (HMODULE) m.AllocationBase;
	}

public:
	// ��ȡ����
	inline  UINT GetInt(PCTSTR ptzKeyName, INT iDefault = 0)
	{
		return GetPrivateProfileInt(m_ptzSecName, ptzKeyName, iDefault, m_tzIniName);
	}

	// ��������
	inline  BOOL SetInt(PCTSTR ptzKeyName, INT iValue = 0)
	{
		TCHAR tzString[16];

		wsprintf(tzString, TEXT("%d"), iValue);
		return WritePrivateProfileString(m_ptzSecName, ptzKeyName, tzString, m_tzIniName);
	}

	// ��ȡ�ַ���
	inline  DWORD GetString(PCTSTR ptzKeyName, PTSTR ptzString, DWORD dwSize = MAX_PATH, PCTSTR ptzDefault = NULL)
	{
		return GetPrivateProfileString(m_ptzSecName, ptzKeyName, ptzDefault, ptzString, dwSize, m_tzIniName);
	}

	// �����ַ���
	inline  BOOL SetString(PCTSTR ptzKeyName, PCTSTR ptzString = NULL)
	{
		return WritePrivateProfileString(m_ptzSecName, ptzKeyName, ptzString, m_tzIniName);
	}

	// ��ȡ�ṹ
	inline  BOOL GetStruct(PCTSTR ptzKeyName, PVOID pvStruct, UINT uSize)
	{
		return GetPrivateProfileStruct(m_ptzSecName, ptzKeyName, pvStruct, uSize, m_tzIniName);
	}

	// ���ýṹ
	inline  BOOL SetStruct(PCTSTR ptzKeyName, PVOID pvStruct, UINT uSize)
	{
		return WritePrivateProfileStruct(m_ptzSecName, ptzKeyName, pvStruct, uSize, m_tzIniName);
	}

	// ��ȡ��
	inline  DWORD GetSection(PTSTR ptzBuffer, DWORD dwSize)
	{
		return GetPrivateProfileSection(m_ptzSecName, ptzBuffer, dwSize, m_tzIniName);
	}

	// ���ý�
	inline  DWORD SetSection(PCTSTR ptzString)
	{
		return WritePrivateProfileSection(m_ptzSecName, ptzString, m_tzIniName);
	}

	// ��ȡ����
	inline  DWORD GetSectionNames(PTSTR ptzBuffer, DWORD dwSize)
	{
		return GetPrivateProfileSectionNames(ptzBuffer, dwSize, m_tzIniName);
	}
};
////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
