//{{NO_DEPENDENCIES}}
// Microsoft Visual C++ generated include file.
// Used by Resource.rc
//
#define IDI_Main                        100
#define IDD_Main                        200
#define IDD_Help                        201
#define IDC_Path                        300
#define IDC_Browse                      303
#define IDC_Tip                         304
#define IDC_Log                         305
#define IDM_Help                        400
#define IDM_About                       401
#define IDM_Exit                        402
#define IDM_Assoc                       403
#define IDM_Clear                       404
#define IDS_Filter                      500
#define IDS_GetFileName                 501
#define IDS_Save                        502
#define IDS_Open                        503
#define IDS_OK                          504
#define IDS_Cancel                      505
#define IDS_AppName                     506
#define IDS_CmdMsg                      507
#define IDS_CmdErr                      508
#define IDS_CmdAsk                      509
#define IDS_Menu                        510
#define IDS_Action                      511
#define IDS_Assoc                       512
#define IDR_Menu                        513
#define IDS_UnAssoc                     513
#define IDS_Ready                       514

// Next default values for new objects
// 
#ifdef APSTUDIO_INVOKED
#ifndef APSTUDIO_READONLY_SYMBOLS
#define _APS_NO_MFC                     1
#define _APS_NEXT_RESOURCE_VALUE        10015
#define _APS_NEXT_COMMAND_VALUE         20122
#define _APS_NEXT_CONTROL_VALUE         30100
#define _APS_NEXT_SYMED_VALUE           40007
#endif
#endif
