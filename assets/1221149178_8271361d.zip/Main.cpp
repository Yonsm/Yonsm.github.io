


////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
// Header
#include "Main.h"
#include "Reg.h"
#include "Helper.h"
#include "MiniCls.h"
#include "Resource.h"
#include <HtmlCtrl.h>
#include <TpcShell.h>
#include <AygShell.h>
#pragma comment(lib, "AygShell.lib")
#pragma comment(lib, "HtmlView.lib")

HWND g_hWnd = NULL;
HINSTANCE g_hInst = NULL;
////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////



////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
// HELP dialog
INT_PTR CALLBACK HELP(HWND hWnd, UINT uMsg, WPARAM wParam, LPARAM lParam)
{
	if (uMsg == WM_INITDIALOG)
	{
		InitHTMLControl(g_hInst);
		CHelper::InitDlgBar(hWnd, FALSE, TBSTATE_HIDDEN);

		TCHAR tzUrl[MAX_PATH];
		TCHAR tzPath[MAX_PATH];
		GetModuleFileName(g_hInst, tzPath, MAX_PATH);
		UStrPrint(tzUrl, TEXT("res://%s/HELP"), tzPath);
		hWnd = CreateWindow(WC_HTML, NULL, WS_CHILD | WS_VISIBLE | HS_CONTEXTMENU, 0, 0, 0, 0, hWnd, (HMENU) IDC_Browse, g_hInst, NULL);
		SendMessage(hWnd, DTM_NAVIGATE, NAVIGATEFLAG_ENTERED, (LPARAM) tzUrl);

		return TRUE;
	}
	else if (uMsg == WM_SIZE)
	{
		MoveWindow(GetDlgItem(hWnd, IDC_Browse), 0, 0, LOWORD(lParam), HIWORD(lParam), TRUE);
	}
	else if (uMsg == WM_COMMAND)
	{
		if ((LOWORD(wParam) == IDOK) || (LOWORD(wParam) == IDCANCEL))
		{
			EndDialog(hWnd, S_OK);
		}
	}

	return FALSE;
}
////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////



////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
// MAIN dialog
INT_PTR CALLBACK MAIN(HWND hWnd, UINT uMsg, WPARAM wParam, LPARAM lParam)
{
	TCHAR tzStr[MAX_STR];
	STATIC CMenuBar s_mb;
	STATIC PCTSTR s_ptzCurFile = NULL;
	STATIC SHACTIVATEINFO s_sa = {sizeof(SHACTIVATEINFO)};

	switch (uMsg)
	{
	case WM_INITDIALOG:
		g_hWnd = hWnd;
		s_ptzCurFile = (PCTSTR) lParam;
		s_mb = CHelper::InitDlgBar(hWnd, TRUE, TBSTATE_ENABLED, TBSTATE_ENABLED, IDR_Menu);
		return TRUE;

	case WM_SIZE:
		CHelper::ReSize(hWnd, IDC_Log, lParam);
		CHelper::ReWidth(hWnd, IDC_Tip, LOWORD(lParam));
		CHelper::ReWidth(hWnd, IDC_Path, CHelper::ReLeft(hWnd, IDC_Browse, LOWORD(lParam)));
		break;

	case WM_ACTIVATE:
		SHHandleWMActivate(hWnd, wParam, lParam, &s_sa, FALSE);
		break;

	case WM_SETTINGCHANGE:
		SHHandleWMSettingChange(hWnd, wParam, lParam, &s_sa);
		break;

	case WM_HOTKEY:
		if (HIWORD(lParam) == VK_TBACK)
		{
			HWND hCtrl = GetDlgItem(hWnd, IDC_Path);
			if (hCtrl != GetFocus())
			{
				SetFocus(hCtrl);
				SetWindowText(hCtrl, NULL);
			}
			else
			{
				SHSendBackToFocusWindow(uMsg, wParam, lParam);
			}
		}
		break;

	case WM_INITMENUPOPUP:
		if (LOWORD(lParam) == IDCANCEL)
		{
			CMenu m;
			HKEY hKey;
			m = (HMENU) wParam;
			if (RegOpenKeyEx(HKEY_CLASSES_ROOT, STR_AppName, 0, KEY_ALL_ACCESS, &hKey) == S_OK)
			{
				RegCloseKey(hKey);
				m.Check(IDM_Assoc, TRUE);
			}
			else
			{
				m.Check(IDM_Assoc, FALSE);
			}
		}
		break;

	case WM_COMMAND:
		switch (LOWORD(wParam))
		{
		case IDC_Browse:
			CHelper::GetFileName(hWnd, _MakeIntRes(IDC_Path), IDS_Filter);
			break;

		case IDC_Path:
			if (HIWORD(wParam) == EN_CHANGE)
			{
				s_mb.EnableButton(IDOK, GetWindowTextLength(GetDlgItem(hWnd, IDC_Path)));
			}
			else if (HIWORD(wParam) == EN_SETFOCUS)
			{
				DWORD dwConversion, dwSentence;
				ImmGetConversionStatus(NULL, &dwConversion, &dwSentence);
				ImmSetConversionStatus(NULL, dwConversion & ~IME_CMODE_NATIVE, NULL);
			}
			break;

		case IDM_Clear:
			SetDlgItemText(g_hWnd, IDC_Log, NULL);
			break;

		case IDM_Assoc:
			CMenu m;
			m = s_mb.GetSubMenu(IDCANCEL);
			if (m.IsChecked(IDM_Assoc))
			{
				ASOC(TEXT("!"));
				ASOC(TEXT("!.ccs"));
				ASOC(TEXT("!.provxml"));
				CHelper::MsgBox(hWnd, IDM_Assoc, _MakeIntRes(IDS_UnAssoc));
			}
			else
			{
				ASOC(TEXT(".ccs"));
				ASOC(TEXT(".provxml"));
				CHelper::MsgBox(hWnd, IDM_Assoc, _MakeIntRes(IDS_Assoc));
			}
			break;

		case IDM_Help:
			return CHelper::DlgBox(hWnd, HELP);

		case IDM_About:
			MessageBox(hWnd, STR_VersionStamp TEXT("\r\n\r\n") STR_BuildStamp TEXT("\r\n\r\n") STR_Copyright TEXT("\r\n\r\n") STR_Web, STR_AppName, MB_ICONINFORMATION);
			break;

		case IDOK:
			if (HIWORD(wParam) == 0)
			{
				GetDlgItemText(hWnd, IDC_Path, tzStr, MAX_PATH);
				Process(tzStr, s_ptzCurFile);
				break;
			}

		case IDCANCEL:
		case IDM_Exit:
			EndDialog(hWnd, S_OK);
			break;
		}
		break;
	}

	return FALSE;
}
////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////



////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
// EXE Entry
INT APIENTRY _tWinMain(HINSTANCE hInstance, HINSTANCE hPrevInstance, PTSTR ptzCmdLine, INT iCmdShow)
{
	TCHAR tzPath[MAX_PATH];
	GetModuleFileName(NULL, tzPath, MAX_PATH);
	g_hInst = hInstance;
	if (*ptzCmdLine)
	{
		return Process(UStrTrim(ptzCmdLine), tzPath);
	}
	else
	{
		HRSRC hRsrc = FindResource(g_hInst, STR_AppName, RT_RCDATA);
		if (hRsrc)
		{
			HGLOBAL hGlobal = LoadResource(g_hInst, hRsrc);
			if (hGlobal)
			{
				return Process((PTSTR) LockResource(hGlobal), tzPath);
			}
		}
		return Process(TEXT("CCUI"), tzPath);
	}
}
////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
