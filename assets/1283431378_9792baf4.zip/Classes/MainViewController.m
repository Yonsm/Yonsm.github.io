//
//  MainViewController.m
//  KBCustom
//
//  Created by Yonsm on 10-9-2.
//  Copyright Yonsm.NET 2010. All rights reserved.
//

#import "MainViewController.h"


@implementation MainViewController


/*
// Implement viewDidLoad to do additional setup after loading the view, typically from a nib.
- (void)viewDidLoad {
	[super viewDidLoad];
}
*/


- (void)flipsideViewControllerDidFinish:(FlipsideViewController *)controller {
    
	[self dismissModalViewControllerAnimated:YES];
}


- (IBAction)showInfo:(id)sender {    
	
	FlipsideViewController *controller = [[FlipsideViewController alloc] initWithNibName:@"FlipsideView" bundle:nil];
	controller.delegate = self;
	
	controller.modalTransitionStyle = UIModalTransitionStyleFlipHorizontal;
	[self presentModalViewController:controller animated:YES];
	
	[controller release];
}


- (void)didReceiveMemoryWarning {
	// Releases the view if it doesn't have a superview.
    [super didReceiveMemoryWarning];
	
	// Release any cached data, images, etc. that aren't in use.
}


- (void)viewDidUnload {
	// Release any retained subviews of the main view.
	// e.g. self.myOutlet = nil;
}


/*
// Override to allow orientations other than the default portrait orientation.
- (BOOL)shouldAutorotateToInterfaceOrientation:(UIInterfaceOrientation)interfaceOrientation {
	// Return YES for supported orientations.
	return (interfaceOrientation == UIInterfaceOrientationPortrait);
}
*/


- (void)dealloc {
	[_normalField release];
	[_crazyField release];
	[_numberField release];
    [super dealloc];
}



// [Yonsm] Handle keyboard show
- (void)keyboardShow:(KBCustomTextField *)sender
{
	if (sender == _numberField)
	{
		[sender addCustomButton:@"NumberPad-Empty" title:@"DONE" target:self action:@selector(onButton:)];
	}
	else
	{
		// Let's crazy!
		UIKBKeyView *keyView = [sender findKeyView:nil];	// Find any key view;
		for (UIKBKeyView *view in keyView.superview.subviews)
		{
			if ([NSStringFromClass([view class]) isEqualToString:@"UIKBKeyView"])
			{
				view.key.displayString = @"X";
				view.key.representedString = @"Crazy";
			}
			else
			{
				NSLog(@"dd %@", NSStringFromClass([view class]));
			}
		}
	}
}

// [Yonsm] Handle keyboard hide
- (void)keyboardHide:(KBCustomTextField *)sender
{
	if (sender == _numberField)
	{
		[sender delCustomButton:@"NumberPad-Empty"];
	}
	else
	{
		// Try to restore crazy keyboard, but here we do nothing
	}
}

// [Yonsm] Handle button event
- (void)onButton:(UIButton *)button
{
	[_normalField resignFirstResponder];
	[_crazyField resignFirstResponder];
	[_numberField resignFirstResponder];
}

@end
