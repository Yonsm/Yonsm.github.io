//
//  KBCustomAppDelegate.h
//  KBCustom
//
//  Created by Yonsm on 10-9-2.
//  Copyright Yonsm.NET 2010. All rights reserved.
//

#import <UIKit/UIKit.h>

@class MainViewController;

@interface KBCustomAppDelegate : NSObject <UIApplicationDelegate> {
    UIWindow *window;
    MainViewController *mainViewController;
}

@property (nonatomic, retain) IBOutlet UIWindow *window;
@property (nonatomic, retain) IBOutlet MainViewController *mainViewController;

@end

