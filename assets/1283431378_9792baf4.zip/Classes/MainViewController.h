//
//  MainViewController.h
//  KBCustom
//
//  Created by Yonsm on 10-9-2.
//  Copyright Yonsm.NET 2010. All rights reserved.
//

#import "FlipsideViewController.h"
#import "KBCustomTextField.h"

@interface MainViewController : UIViewController <FlipsideViewControllerDelegate> {
	IBOutlet UITextField *_normalField;
	IBOutlet KBCustomTextField *_crazyField;
	IBOutlet KBCustomTextField *_numberField;
}

- (IBAction)showInfo:(id)sender;


@end
