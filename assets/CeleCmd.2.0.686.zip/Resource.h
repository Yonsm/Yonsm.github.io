//{{NO_DEPENDENCIES}}
// Microsoft Visual C++ generated include file.
// Used by Resource.rc
//
#define IDI_Main                        100
#define IDI_File                        101
#define IDD_Main                        200
#define IDD_Help                        201
#define IDR_DlgMenu                     250
#define IDR_MainMenu                    251
#define IDC_Path                        300
#define IDC_Browse                      303
#define IDC_Tip                         304
#define IDC_Log                         305
#define IDM_Help                        400
#define IDM_About                       401
#define IDM_Exit                        402
#define IDM_Assoc                       403
#define IDM_Clear                       404
#define IDS_Ready                       516
#define IDS_AppName                     800
#define IDS_AppDesc                     801
#define IDS_Copyright                   802
#define IDS_Help                        803
#define IDS_Filter                      810
#define IDS_GetFileName                 811
#define IDS_PromptFile                  811
#define IDS_Save                        812
#define IDS_Open                        813
#define IDS_OK                          814
#define IDS_Cancel                      815
#define IDS_CmdMsg                      817
#define IDS_CmdErr                      818
#define IDS_CmdAsk                      819
#define IDS_Menu                        820
#define IDS_Action                      821
#define IDS_Assoc                       822
#define IDS_UnAssoc                     823

// Next default values for new objects
// 
#ifdef APSTUDIO_INVOKED
#ifndef APSTUDIO_READONLY_SYMBOLS
#define _APS_NO_MFC                     1
#define _APS_NEXT_RESOURCE_VALUE        10016
#define _APS_NEXT_COMMAND_VALUE         20122
#define _APS_NEXT_CONTROL_VALUE         30100
#define _APS_NEXT_SYMED_VALUE           40007
#endif
#endif
