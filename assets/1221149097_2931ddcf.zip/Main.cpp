


////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
// Header
#include "Aeon.h"
#include "Main.h"
#include "CeleSign.h"
#include "AboutDlg.h"
#include <CommCtrl.h>

#pragma warning(disable:4244)
#pragma comment(lib, "ShLwAPI.lib")
#pragma comment(lib, "ComCtl32.lib")
////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////



////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
// Global
HWND g_hWnd = NULL;
HWND g_hPage = NULL;
HINSTANCE g_hInst = NULL;

#pragma data_seg(AEON_SEG)
UINT g_uCurPage = 2;
UINT g_uRecursive = 0;
TCHAR g_tzPVK[MAX_PATH] = {0};
TCHAR g_tzSPC[MAX_PATH] = {0};
#pragma data_seg()
////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////



////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
// Browse file path
BOOL BrowseFile(HWND hWnd, UINT uCtrl, UINT uFilter, BOOL bSave = FALSE)
{
	TCHAR tzStr[MAX_STR];
	TCHAR tzPath[MAX_PATH];

	GetDlgItemText(hWnd, uCtrl, tzPath, MAX_PATH);
	UStrRep(_GetStr(uFilter), '|', 0);

	OPENFILENAME ofn = {0};
	ofn.hwndOwner = hWnd;
	ofn.hInstance = g_hInst;
	ofn.lpstrFile = tzPath;
	ofn.lpstrFilter = tzStr;
	ofn.nMaxFile = MAX_PATH;
	ofn.lStructSize = sizeof(OPENFILENAME);

	// Parse default extension
	TCHAR tzDefExt[MAX_NAME];
	PTSTR p = tzStr + UStrLen(tzStr) + 1;
	if (p = UStrChr(p, '.'))
	{
		UStrCopy(tzDefExt, p);
		if (p = UStrChr(tzDefExt, ';')) *p = 0;
		ofn.lpstrDefExt = tzDefExt;
	}

	BOOL bRet;
	if (bSave)
	{
		ofn.Flags = OFN_ENABLESIZING | OFN_PATHMUSTEXIST | OFN_HIDEREADONLY | OFN_OVERWRITEPROMPT;
		bRet = GetSaveFileName(&ofn);
	}
	else
	{
		ofn.Flags = OFN_ENABLESIZING | OFN_PATHMUSTEXIST | OFN_HIDEREADONLY | OFN_FILEMUSTEXIST;
		bRet = GetOpenFileName(&ofn);
	}

	if (bRet)
	{
		SetDlgItemText(hWnd, uCtrl, tzPath);
	}

	return bRet;
}
////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////



////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
// Sign dialog
INT_PTR CALLBACK PageDlgProc(HWND hWnd, UINT uMsg, WPARAM wParam, LPARAM lParam)
{
	switch (uMsg)
	{
	case WM_INITDIALOG:
		SetDlgItemText(hWnd, IDC_PVK, g_tzPVK);
		SetDlgItemText(hWnd, IDC_SPC, g_tzSPC);
		if (g_uRecursive) CheckDlgButton(hWnd, IDC_Recursive, BST_CHECKED);
		return TRUE;

	case WM_COMMAND:
		switch (LOWORD(wParam))
		{
		case IDC_Browse:
			BrowseFile(hWnd, IDC_Path, IDS_Filter);
			break;

		case IDC_BrowseCer:
			BrowseFile(hWnd, IDC_Path, IDS_FilterCer, TRUE);
			break;

		case IDC_BrowseSPC:
			BrowseFile(hWnd, IDC_SPC, IDS_FilterSpc);
			break;

		case IDC_BrowsePVK:
			BrowseFile(hWnd, IDC_PVK, IDS_FilterPvk);
			break;

		case IDC_Path:
			if (HIWORD(wParam) == EN_CHANGE)
			{
				TCHAR tzStr[MAX_PATH];
				GetDlgItemText(hWnd, IDC_Path, tzStr, MAX_PATH);
				EnableWindow(GetDlgItem(g_hWnd, IDOK), tzStr[0]);

				if (g_uCurPage == 2)
				{
					PTSTR p = UDirSplitPath(tzStr);
					PTSTR q = UStrChr(p, '.');
					if (q) *q = 0;
					SetDlgItemText(hWnd, IDC_Name, p);
					UStrCat(p, TEXT("@CeleWare.NET"));
					SetDlgItemText(hWnd, IDC_Mail, p);
				}
			}
		}
		break;
	}

	return FALSE;
}
////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////



////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
// Tab control change
VOID OnTabChange(PTSTR ptzPath = NULL)
{
	if (g_hPage)
	{
		DestroyWindow(g_hPage);
	}

	HWND hTab = GetDlgItem(g_hWnd, IDC_Tab);
	g_uCurPage = TabCtrl_GetCurSel(hTab);
	g_hPage = CreateDialog(g_hInst, MAKEINTRESOURCE(IDD_Sign + g_uCurPage), g_hWnd, PageDlgProc);

	RECT rt;
	GetClientRect(hTab, &rt); 
	TabCtrl_AdjustRect(hTab, FALSE, &rt);
	MapWindowPoints(hTab, g_hWnd, (PPOINT) &rt, 2);
	SetWindowPos(g_hPage, HWND_TOP, rt.left, rt.top, 0, 0, SWP_NOSIZE | SWP_SHOWWINDOW);

	TCHAR tzStr[MAX_PATH];
	if (ptzPath && ptzPath[0])
	{
		UStrCopyN(tzStr, ptzPath, MAX_PATH);
		SetDlgItemText(g_hPage, IDC_Path, UStrTrim(tzStr, '"'));
	}

	if (LoadString(g_hInst, IDS_Sign + g_uCurPage, tzStr, MAX_PATH))
	{
		SetDlgItemText(g_hWnd, IDOK, tzStr);
	}
}
////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////



////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
// Take action
VOID OnOK()
{
	SetFocus(GetDlgItem(g_hWnd, IDC_Log));
	SetDlgItemText(g_hWnd, IDC_Log, NULL);

	TCHAR tzStr[MAX_PATH];
	GetDlgItemText(g_hPage, IDC_Path, tzStr, MAX_PATH);
	g_uRecursive = IsDlgButtonChecked(g_hPage, IDC_Recursive);

	if (g_uCurPage == 2)
	{
		CCeleSign::Create(tzStr);
	}
	else
	{
		if (g_uCurPage == 1)
		{
		}
		else
		{
			GetDlgItemText(g_hPage, IDC_PVK, g_tzPVK, MAX_PATH);
			GetDlgItemText(g_hPage, IDC_SPC, g_tzSPC, MAX_PATH);
			if (!UFileExist(g_tzSPC) || !UFileExist(g_tzSPC))
			{
				SendMessage(g_hWnd, LB_ADDSTRING, MSG_NeedCert, 0);
				TabCtrl_SetCurSel(GetDlgItem(g_hWnd, IDC_Tab), 2);
				OnTabChange();
				return;
			}
		}
		CCeleSign::EnumPath(tzStr);
	}
}
////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////



////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
// Main dialog
INT_PTR CALLBACK MainDlgProc(HWND hWnd, UINT uMsg, WPARAM wParam, LPARAM lParam)
{
	TCHAR tzStr[MAX_PATH];
	switch (uMsg)
	{
	case WM_INITDIALOG:
		g_hWnd = hWnd;
		MainDlgProc(hWnd, WM_COMMAND, MAKELONG(IDC_Log, EN_KILLFOCUS), 0);
		SetClassLongPtr(hWnd, GCL_HICON, (LONG_PTR) LoadIcon(GetModuleHandle(NULL), _MakeIntRes(IDI_Main)));
		if (HWND hTab = GetDlgItem(hWnd, IDC_Tab))
		{
			TCITEM ti;
			ti.mask = TCIF_TEXT;
			ti.pszText = tzStr;
			for (UINT i = 0; LoadString(g_hInst, IDS_Sign + i, tzStr, MAX_NAME); i++)
			{
				TabCtrl_InsertItem(hTab, i, &ti);
			}
			TabCtrl_SetCurSel(hTab, g_uCurPage);
			OnTabChange((PTSTR) lParam);

			HFONT hFont = (HFONT) SendMessage(hWnd, WM_GETFONT, 0, 0);
			if (hFont)
			{
				LOGFONT lf;
				GetObject(hFont, sizeof(LOGFONT), &lf);
				lf.lfHeight *= 2;
				lf.lfItalic = TRUE;
				hFont = CreateFontIndirect(&lf);
				SendDlgItemMessage(hWnd, IDC_Brand, WM_SETFONT, (WPARAM) hFont, 0);
			}
		}
		return TRUE;

	case WM_DROPFILES:
		DragQueryFile((HDROP) wParam, 0, tzStr, MAX_PATH);
		DragFinish((HDROP) wParam);
		SetDlgItemText(g_hPage, IDC_Path, tzStr);
		break;

	case WM_COMMAND:
		switch (LOWORD(wParam))
		{
		case IDOK:
			OnOK();
			break;

		case IDC_About:
			//MessageBox(hWnd, STR_VersionStamp TEXT("\r\n\r\n") STR_BuildStamp TEXT("\r\n\r\n") STR_Copyright, STR_AppName, MB_ICONINFORMATION);
			CAboutDlg::Show(hWnd);
			break;

		case IDCANCEL:
			EndDialog(hWnd, 0);
			break;

		case IDC_Brand:
			if (HIWORD(wParam) == STN_DBLCLK)
			{
				SetDlgItemText(g_hWnd, IDC_Log, NULL);
				CCeleSign::ResExec(IDR_SPDPS, TEXT(" /device"));
				SetFocus(GetDlgItem(g_hWnd, IDC_Log));
			}
			break;

		case IDC_Log:
			if ((HIWORD(wParam) == EN_KILLFOCUS) || (HIWORD(wParam) == EN_SETFOCUS))
			{
				static INT h = 0;
				static RECT rt = {0};
				if (h == 0)
				{
					GetWindowRect(GetDlgItem(hWnd, IDC_Log), &rt);
					h = rt.top;
					GetWindowRect(hWnd, &rt);
					h -= rt.top + 2;
					rt.right -= rt.left;
					rt.bottom -= rt.top;
				}
				MoveWindow(hWnd, rt.left, rt.top, rt.right, (HIWORD(wParam) == EN_KILLFOCUS) ? h : rt.bottom, TRUE);
			}
			break;
		}
		break;

	case LB_ADDSTRING:
		TCHAR tzLog[MAX_STR];
		UStrPrint(tzLog, _IsIntRes(wParam) ? _GetStr(wParam) : (PTSTR) wParam, lParam);
		SendDlgItemMessage(hWnd, IDC_Log, EM_SETSEL, -1, 0);
		SendDlgItemMessage(hWnd, IDC_Log, EM_REPLACESEL, FALSE, (LPARAM) tzLog);
		break;

	case WM_NOTIFY:
		if (((LPNMHDR) lParam)->code == TCN_SELCHANGE)
		{
			OnTabChange();
		}
		break;
	}

	return FALSE;
}
////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////



////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
// Entry
INT APIENTRY _tWinMain(HINSTANCE hInstance, HINSTANCE hPrevInstance, PTSTR ptzCmdLine, INT iShowCmd)
{
	AeonInit();
	g_hInst = hInstance;
	InitCommonControls();
	DialogBoxParam(g_hInst, MAKEINTRESOURCE(IDD_Main), NULL, MainDlgProc, (LPARAM) ptzCmdLine);
	AeonExit();
	return 0;
}
////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
