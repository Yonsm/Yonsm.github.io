


////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
// Header
#pragma once
#include <Windows.h>
////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////



////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
// CMemFile class
class CMemFile
{
private:
	HANDLE m_hFile;
	HANDLE m_hMapping;
	PVOID m_pvFile;
	DWORD m_dwSize;
	DWORD m_dwNewSize;

public:
	operator DWORD() const {return m_dwSize;}
	operator PVOID() const {return m_pvFile;}
	operator PBYTE() const {return (PBYTE) m_pvFile;}
	operator PCHAR() const {return (PCHAR) m_pvFile;}
	operator PWCHAR() const {return (PWCHAR) m_pvFile;}
	BOOL operator !() {return (m_pvFile == NULL);}
	DWORD operator =(DWORD dwSize) {return m_dwNewSize = dwSize;}

public:
	CMemFile(PCTSTR ptzPath, BOOL bReadOnly = FALSE)
	{
		m_dwSize = 0;
		m_dwNewSize = 0;
		m_pvFile = NULL;
		m_hMapping = NULL;
		m_hFile = CreateFile(ptzPath,
			bReadOnly ? GENERIC_READ : (GENERIC_READ | GENERIC_WRITE),
			bReadOnly ? FILE_SHARE_READ : (FILE_SHARE_READ | FILE_SHARE_WRITE),
			NULL, OPEN_EXISTING, FILE_ATTRIBUTE_NORMAL, NULL);
		if (m_hFile != INVALID_HANDLE_VALUE)
		{
			m_dwSize = GetFileSize(m_hFile, NULL);
			if ((m_dwSize != 0) && (m_dwSize != INVALID_FILE_SIZE))
			{
				m_hMapping = CreateFileMapping(m_hFile, NULL, bReadOnly ? PAGE_READONLY : PAGE_READWRITE, 0, m_dwSize, NULL);
				if (m_hMapping)
				{
					m_pvFile = MapViewOfFile(m_hMapping, bReadOnly ? FILE_MAP_READ : FILE_MAP_ALL_ACCESS, 0, 0, 0);
				}
			}
		}
	}

	~CMemFile()
	{
		if (m_pvFile)
		{
			UnmapViewOfFile(m_pvFile);
		}
		if (m_hMapping)
		{
			CloseHandle(m_hMapping);
		}
		if (m_hFile != INVALID_HANDLE_VALUE)
		{
			if (m_dwNewSize)
			{
				SetFilePointer(m_hFile, m_dwNewSize, NULL, FILE_BEGIN);
				SetEndOfFile(m_hFile);
			}
			CloseHandle(m_hFile);
		}
	}
};
////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
