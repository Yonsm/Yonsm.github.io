


////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
// Header
#include "Main.h"
#include "CeleSign.h"
#include "MemFile.h"
////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////



////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
// Execute command from resource
HRESULT CCeleSign::ResExec(UINT uExeID, PTSTR ptzParam)
{
	HRSRC hRsrc = FindResource(g_hInst, MAKEINTRESOURCE(uExeID), RT_RCDATA);
	if (!hRsrc)
	{
		return ERR_Exception;
	}

	HGLOBAL hGlobal = LoadResource(g_hInst, hRsrc);
	if (!hGlobal)
	{
		return ERR_Exception;
	}

	TCHAR tzPath[MAX_PATH];
	UDirGetTempFile(tzPath);
	if (!UFileSave(tzPath, LockResource(hGlobal), SizeofResource(g_hInst, hRsrc), UFILE_WRITE))
	{
		return ERR_SaveFile;
	}

	HANDLE hRead, hWrite;
	SECURITY_ATTRIBUTES sa;
	sa.nLength = sizeof (sa);
	sa.bInheritHandle = TRUE;
	sa.lpSecurityDescriptor = NULL;	
	if (!CreatePipe(&hRead, &hWrite, &sa, 0))
	{
		return ERR_Exception;
	}

	STARTUPINFO si = {0};
	PROCESS_INFORMATION pi;
	si.cb = sizeof(si);
	si.dwFlags = STARTF_USESTDHANDLES | STARTF_USESHOWWINDOW;
	si.wShowWindow = SW_HIDE;
	si.hStdError = hWrite;
	si.hStdOutput = hWrite;
	HRESULT hResult = ERR_ExecErr;
	if (CreateProcess(tzPath, ptzParam, NULL, NULL, TRUE, 0, NULL, NULL, &si, &pi))
	{
		WaitForSingleObject(pi.hProcess, INFINITE);

		DWORD dwSize;
		CHAR szStr[MAX_STR];
		if (PeekNamedPipe(hRead, szStr, sizeof(szStr), &dwSize, 0, 0) && dwSize)
		{
			//ReadFile(hRead, szStr, sizeof(szStr), &dwSize, NULL);
			szStr[dwSize] = 0;
			SendMessage(g_hWnd, LB_ADDSTRING, MSG_ExecOut, (LPARAM) szStr);
		}
		CloseHandle(pi.hThread);
		CloseHandle(pi.hProcess);
		hResult = MSG_ExecOK;
	}

	CloseHandle(hRead);
	CloseHandle(hWrite);
	DeleteFile(tzPath);

	return hResult;
}
////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////



////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
// Sign string from file
HRESULT CCeleSign::Sign(PTSTR ptzPath)
{
	// Try to fix file from reference
	TCHAR tzRef[MAX_PATH];
	UStrCopy(tzRef, ptzPath);
	PTSTR p = UStrRChr(tzRef, '\\');
	if (p)
	{
		*p = 0;
		PTSTR q = UStrRChr(tzRef, '\\');
		if (q)
		{
			UStrCopy(q + 1, p + 1);
			CMemFile fRef(tzRef, TRUE);
			if (!!fRef)
			{
				HANDLE hFile = UFileOpen(ptzPath, UFILE_APPEND);
				if (hFile)
				{
					DWORD dwSize = UFileGetSize(hFile);
					if (fRef > dwSize)
					{
						WriteFile(hFile, (PBYTE) fRef + dwSize, (DWORD) fRef - dwSize, &dwSize, NULL);
						SendMessage(g_hWnd, LB_ADDSTRING, MSG_SignFix, (LPARAM) ptzPath);
					}
					UFileClose(hFile);
				}
			}
		}
	}

	TCHAR tzParam[MAX_STR];
	UStrPrint(tzParam, TEXT(" -v \"%s\" -spc \"%s\" \"%s\""), g_tzPVK, g_tzSPC, ptzPath);
	return ResExec(IDR_SIGNCODE, tzParam);
}
////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////



////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
// Write back to target file
HRESULT CCeleSign::Remove(PTSTR ptzPath)
{
	CMemFile f(ptzPath);
	if (!f)
	{
		return ERR_MapFile;
	}

	// Verify DOS signature
	PBYTE pbFile = f;
	if (((PIMAGE_DOS_HEADER) pbFile)->e_magic == IMAGE_DOS_SIGNATURE)
	{
		// Verify PE signature
		PIMAGE_NT_HEADERS pNTHdr = (PIMAGE_NT_HEADERS) (pbFile + ((PIMAGE_DOS_HEADER) pbFile)->e_lfanew);
		if (pNTHdr->Signature == IMAGE_NT_SIGNATURE)
		{
			PDWORD pdwSize = &pNTHdr->OptionalHeader.DataDirectory[IMAGE_DIRECTORY_ENTRY_SECURITY].Size;
			PDWORD pdwVA = &pNTHdr->OptionalHeader.DataDirectory[IMAGE_DIRECTORY_ENTRY_SECURITY].VirtualAddress;
			if (*pdwVA)
			{
				// Remove sign data
				if (*pdwVA + *pdwSize == (DWORD) f)
				{
					f = *pdwVA;
				}

				// Remove signature entry and checksum
				*pdwVA = *pdwSize = 0;
				pNTHdr->OptionalHeader.CheckSum = 0;

				return MSG_RemoveOK;
			}
			else
			{
				return MSG_RemoveNothing;
			}
		}
	}

	return ERR_InvalidPE;
}
////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////



////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
// Create and replace string
HRESULT CCeleSign::Create(PCTSTR ptzPath)
{
	TCHAR tzName[64];
	TCHAR tzMail[64];
	TCHAR tzParam[1024];

	UStrCopy(g_tzPVK, ptzPath);
	PTSTR p = UStrRChr(g_tzPVK, '.');
	if (!p) p = g_tzPVK + UStrLen(g_tzPVK);
	UStrCopy(p, TEXT(".pvk"));

	UStrCopy(g_tzSPC, ptzPath);
	p = UStrRChr(g_tzSPC, '.');
	if (!p) p = g_tzSPC + UStrLen(g_tzSPC);
	UStrCopy(p, TEXT(".spc"));

	GetDlgItemText(g_hPage, IDC_Name, tzName, _NumOf(tzName));
	GetDlgItemText(g_hPage, IDC_Mail, tzMail, _NumOf(tzMail));
	UStrPrint(tzParam, TEXT(" -n \"CN=%s;E=%s;OU=WWW.CeleWare.NET;O=CeleWare.NET;\" -sv \"%s\" \"%s\""), tzName, tzMail, g_tzPVK, ptzPath);
	HRESULT hResult = ResExec(IDR_MAKECERT, tzParam);
	if (hResult != MSG_ExecOK)
	{
		return hResult;
	}

	UStrPrint(tzParam, TEXT(" \"%s\" \"%s\""), ptzPath, g_tzSPC);
	return ResExec(IDR_CERT2SPC, tzParam);
}
////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////



////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
// Enum path
HRESULT CCeleSign::EnumPath(PTSTR ptzPath)
{
	HRESULT hResult = ERR_FileNotFound;

	WIN32_FIND_DATA fd;
	TCHAR tzPath[MAX_PATH];
	HANDLE hFind = FindFirstFile(ptzPath, &fd);
	if (hFind == INVALID_HANDLE_VALUE)
	{
		SendMessage(g_hWnd, LB_ADDSTRING, ERR_FileNotFound, (LPARAM) ptzPath);
	}

	PTSTR ptzFile = UDirSplitPath(ptzPath);
	if (hFind != INVALID_HANDLE_VALUE)
	{
		do
		{
			if (!(fd.dwFileAttributes & FILE_ATTRIBUTE_DIRECTORY))
			{
				UStrPrint(tzPath, (ptzPath == ptzFile) ? fd.cFileName : TEXT("%s\\%s"), ptzPath, fd.cFileName);

				// Tack action
				if (g_uCurPage == 0)
				{
					hResult = Sign(tzPath);
				}
				else if (g_uCurPage == 1)
				{
					hResult = Remove(tzPath);
				}
				else
				{
					hResult = Create(tzPath);
				}
				if (hResult != MSG_ExecOK)
				{
					SendMessage(g_hWnd, LB_ADDSTRING, hResult, (LPARAM) tzPath);
				}
			}
		}
		while (FindNextFile(hFind, &fd));
		FindClose(hFind);
	}

	if (g_uRecursive)
	{
		// Enum sub directory
		UStrPrint(tzPath, TEXT("%s\\*"), ptzPath);
		HANDLE hFind = FindFirstFile(tzPath, &fd);
		if (hFind != INVALID_HANDLE_VALUE)
		{
			do
			{
				if ((fd.cFileName[0] != '.') && (fd.dwFileAttributes & FILE_ATTRIBUTE_DIRECTORY))
				{
					if (ptzPath == ptzFile)
					{
						UStrPrint(tzPath, TEXT("%s\\%s"), fd.cFileName, ptzFile);
					}
					else
					{
						UStrPrint(tzPath, TEXT("%s\\%s\\%s"), ptzPath, fd.cFileName, ptzFile);
					}
					EnumPath(tzPath);
				}
			}
			while (FindNextFile(hFind, &fd));
			FindClose(hFind);
		}
	}

	return hResult;
}
////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
