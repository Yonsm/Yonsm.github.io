//{{NO_DEPENDENCIES}}
// Microsoft Visual C++ generated include file.
// Used by Resource.rc
//
#define IDI_Main                        100
#define IDI_Sign                        101
#define IDI_Remove                      102
#define IDI_Create                      103
#define IDD_Main                        200
#define IDD_Sign                        201
#define IDD_Remove                      202
#define IDD_Create                      203
#define IDC_Path                        300
#define IDC_Browse                      303
#define IDC_BrowseCer                   304
#define IDC_BrowseSPC                   305
#define IDC_Tab                         307
#define IDC_BrowsePVK                   308
#define IDC_About                       308
#define IDC_Recursive                   310
#define IDC_Brand                       312
#define IDC_Mail                        314
#define IDC_Log                         316
#define IDC_Name                        317
#define IDS_Filter                      501
#define IDS_FilterCer                   502
#define IDS_FilterPvk                   503
#define IDS_FilterSpc                   504
#define ERR_ExecErr                     505
#define ERR_FileNotFound                506
#define MSG_ExecOK                     507
#define MSG_NeedCert                    508
#define MSG_ExecOut                     509
#define ERR_InvalidPE                   510
#define MSG_SignFix                     514
#define ERR_Exception                   520
#define ERR_AllocMemory                 521
#define ERR_OpenFile                    522
#define ERR_MapFile                     523
#define ERR_SaveFile                    524
#define MSG_RemoveOK                    525
#define IDS_RemoveNothing               526
#define MSG_RemoveNothing               526
#define IDS_Sign                        550
#define IDS_Remove                      551
#define IDS_Create                      552
#define IDR_SIGNCODE                    600
#define IDR_MAKECERT                    601
#define IDR_CERT2SPC                    602
#define IDR_SPDPS                       603
#define IDC_PVK                         700
#define IDC_SPC                         701

// Next default values for new objects
// 
#ifdef APSTUDIO_INVOKED
#ifndef APSTUDIO_READONLY_SYMBOLS
#define _APS_NO_MFC                     1
#define _APS_NEXT_RESOURCE_VALUE        10014
#define _APS_NEXT_COMMAND_VALUE         20112
#define _APS_NEXT_CONTROL_VALUE         30099
#define _APS_NEXT_SYMED_VALUE           40005
#endif
#endif
