<?php get_header(); ?>

	<div id="content"> 
        <div id="entries-a">
            <div id="entries2">
                <?php if (have_posts()) : ?>
                <?php while (have_posts()) : the_post(); ?>
				<?php if(!isset($c)){$c=0;} $c++; if( $c == 1) :?>
                <?php $i = 1; ?>

                    <!-- start entry post -->
                    <div class="post pi1" id="post-<?php the_ID(); ?>">                                                          
                        <div class="entry">  
                            <div class="entryinfo">                     	
                            	<h2><a href="<?php the_permalink() ?>" rel="bookmark" title="Permanent Link to <?php the_title_attribute(); ?>"><?php the_title(); ?></a></h2>
                                <?php edit_post_link('Edit', '<span class="edit">', '</span>'); ?> <span class="author"><?php the_author() ?></span> <span class="date"><?php the_time('jS F Y') ?></span> <span class="comment_count"><?php comments_popup_link('0 Comments', '1 Comment', '% Comments'); ?></span>                                              
                            </div>
                            <a href="<?php the_permalink() ?>" rel="bookmark" title="Permanent Link to <?php the_title(); ?>"><?php the_post_thumbnail(); ?></a>                    
                            <p class="pmar"><?php echo sitetrail_limit_words(get_the_excerpt(), '54'); ?>.</p>
                            <a class="readmore" href="<?php the_permalink() ?>" rel="bookmark" title="Permanent Link to <?php the_title_attribute(); ?>">Read More &rarr;</a>
                            <div class="clearer"></div>                   
                        </div>
                    </div>
                    <!-- end entry post -->
                    
                    <?php else :?>
                    <div class="post pi" id="post-<?php the_ID(); ?>">                                                          
                        <div class="entry">  
                            <div class="entryinfo">                     	
                            	<h2><a href="<?php the_permalink() ?>" rel="bookmark" title="Permanent Link to <?php the_title_attribute(); ?>"><?php the_title(); ?></a></h2>
                                <?php edit_post_link('Edit', '<span class="edit">', '</span>'); ?> <span class="author"><?php the_author() ?></span> <span class="date"><?php the_time('jS F Y') ?></span> <span class="comment_count"><?php comments_popup_link('0 Comments', '1 Comment', '% Comments'); ?></span>                                              
                            </div>
                            <a href="<?php the_permalink() ?>" rel="bookmark" title="Permanent Link to <?php the_title(); ?>"><?php the_post_thumbnail(); ?></a>                  
                            <p class="pmar"><?php echo sitetrail_limit_words(get_the_excerpt(), '54'); ?>.</p>
                            <a class="readmore" href="<?php the_permalink() ?>" rel="bookmark" title="Permanent Link to <?php the_title_attribute(); ?>">Read More &rarr;</a>
                            <div class="clearer"></div>                   
                        </div>
                    </div>
                    <!-- end entry post -->
                    <?php endif;?>
                
				<?php $i++; ?>        
                <?php endwhile; ?>
                <div class="clearer"></div>
                <div class="navigation mar">
                    <div class="alignleft"><?php next_posts_link('Previous') ?></div>
                    <div class="alignright"><?php previous_posts_link('Next') ?></div>
                    <div class="clearer"></div>
                </div>
            
                <?php else : ?>
            
        
                    <div class="post si">
                        <div class="entry">
                            <h2>No Results</h2>
                            No matches found. Please try again.
                        </div>
                    </div>
            
                <?php endif; ?>                     
            </div>
        </div>
	</div>

<?php get_sidebar(); ?>

<?php get_footer(); ?>