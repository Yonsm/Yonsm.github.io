<?php
global $themesbysitetrail_options;
$themesbysitetrail_settings = get_option( 'themesbysitetrail_options', $themesbysitetrail_options );

if(!empty($themesbysitetrail_settings['ad_count']))
{
?>
<div class="ad125x125">
	<div class="ad125x125b">
    
    	<?php for($i=1; $i<=$themesbysitetrail_settings['ad_count']; $i++){ ?>
    	<!-- AD BOX #<?php echo $i; ?> GO HERE -->
        <a href="<?php if( $themesbysitetrail_settings["ad125x125_link$i"] != '' ) : ?> <?php echo $themesbysitetrail_settings["ad125x125_link$i"]; ?> <?php endif; ?>"><img src="<?php if( $themesbysitetrail_settings["ad125x125_img$i"] != '' ) : ?> <?php echo $themesbysitetrail_settings["ad125x125_img$i"]; ?> <?php else : ?> <?php echo get_template_directory_uri(); ?>/images/ad125x125.jpg <?php endif; ?>" alt="Advertise your site here!" class="<?php if($i%2 !== 0) echo 'adboxleft'; else echo 'adboxright'; ?>" /></a>
        <!-- END AD BOX #<?php echo $i; ?> -->
        <?php } ?>
                     
    	<div class="clearer"></div>
    </div>
</div>
<?php
}
?>