<?php  get_header(); ?>

	<div id="content">
		<div id="entries">
        	<div id="entries2">            
			<?php if (have_posts()) : while (have_posts()) : the_post(); ?>
        
                <!-- start entry post -->
                <div <?php post_class("post si"); ?> id="post-<?php the_ID(); ?>">                                                         
                    <div class="etext">
                        <div class="entryinfo">                     	
                            <h2><a href="<?php the_permalink() ?>" rel="bookmark" title="Permanent Link to <?php the_title_attribute(); ?>"><?php the_title(); ?></a></h2>
                            <?php edit_post_link('Edit', '<span class="edit">', '</span>'); ?> <span class="author"><?php the_author() ?></span> <span class="date"><?php the_time('jS F Y') ?></span> <span class="comment_count"><?php comments_popup_link('0 Comments', '1 Comment', '% Comments'); ?></span>                                             
                        </div>                    
                        <?php the_content(); ?>
						<?php wp_link_pages( array( 'before' => '<div class="page-link">' . __( 'Pages:', 'idris' ), 'after' => '</div>' ) ); ?>
                        <?php if(has_category()){echo '<div class="details">This article was filed under '; the_category(', '); echo '.</div>';} ?>
                        <?php if(has_tag()){echo '<div class="details">Tagged with '; the_tags('', ', ', ''); echo '.</div>';} ?>
                        <nav id="nav-single">
                            <span class="nav-previous"><?php previous_post_link( '%link', __( '<span class="meta-nav">&larr;</span> Previous', 'idris' ) ); ?></span>
                            <span class="nav-next"><?php next_post_link( '%link', __( 'Next <span class="meta-nav">&rarr;</span>', 'idris' ) ); ?></span>
                        </nav>
                        <div id="commentsarea">
                            <?php comments_template(); ?>
                        </div>
                    </div>   
                </div>
                <!-- end entry post -->	
           
            <?php endwhile; else: ?>
        
                <div class="post si">
                        <h2>Error 404 Page.</h2>
                    <div class="entry">
                        Sorry, but you are looking for something that isn't here.
                    </div>
                </div>
        
                <?php endif; ?>
			</div>
        </div>
        
	</div>

<?php get_sidebar(); ?>

<?php get_footer(); ?>
