<?php get_header(); ?>

<div id="content">
    <div id="entries">
        <div id="entries2">
            <div class="post si">
                <div class="entry">
                    <div class="entryinfo">
                        <h2>Error 404</h2>
                        Sorry, but you are looking for something that isn't here.
                    </div>
                </div>
            </div>
		</div>
    </div>
</div>

<?php get_sidebar(); ?>

<?php get_footer(); ?>