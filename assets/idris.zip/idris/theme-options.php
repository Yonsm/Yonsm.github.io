<?php

// Default options values
$themesbysitetrail_options = array(
	'footer_copyright' => '&copy; ' . date('Y') . ' ' . get_bloginfo('name').'.',
	'featured_cat' => '0',
	'ad_count' => '4',
	'ad125x125_link1' => '',
	'ad125x125_link2' => '',
	'ad125x125_link3' => '',
	'ad125x125_link4' => '',
	'ad125x125_img1' => '',
	'ad125x125_img2' => '',
	'ad125x125_img3' => '',
	'ad125x125_img4' => ''
);

if ( is_admin() ) : // Load only if we are viewing an admin page

function themesbysitetrail_register_settings() {
	// Register settings and call sanitation functions
	register_setting( 'themesbysitetrail_theme_options', 'themesbysitetrail_options', 'themesbysitetrail_validate_options' );
}

add_action( 'admin_init', 'themesbysitetrail_register_settings' );

// Store categories in array
$themesbysitetrail_categories[0] = array(
	'value' => 0,
	'label' => ''
);
$themesbysitetrail_cats = get_categories(); $i = 1;
foreach( $themesbysitetrail_cats as $themesbysitetrail_cat ) :
	$themesbysitetrail_categories[$themesbysitetrail_cat->cat_ID] = array(
		'value' => $themesbysitetrail_cat->cat_ID,
		'label' => $themesbysitetrail_cat->cat_name
	);
	$i++;
endforeach;

function themesbysitetrail_theme_options() {
	// Add theme options page to the addmin menu
	add_theme_page( 'Theme Options', 'Theme Options', 'edit_theme_options', 'theme_options', 'themesbysitetrail_theme_options_page' );
}

add_action( 'admin_menu', 'themesbysitetrail_theme_options' );

// Function to generate options page
function themesbysitetrail_theme_options_page() {
	global $themesbysitetrail_categories;

	if ( ! isset( $_REQUEST['updated'] ) )
		$_REQUEST['updated'] = false; // This checks whether the form has just been submitted. ?>

	<div class="wrap">

	<?php screen_icon(); echo "<h2>" . get_current_theme() . ' Theme Options' . "</h2>";
	// This shows the page's name and an icon if one has been provided ?>

	<?php if ( false !== $_REQUEST['updated'] ) : ?>
	<div class="updated fade"><p><strong>Options saved</strong></p></div>
	<?php endif; // If the form has just been submitted, this shows the notification ?>

	<form method="post" action="options.php">

	<?php if(!isset($themesbysitetrail_options)){$themesbysitetrail_options = array();} $settings = get_option( 'themesbysitetrail_options', $themesbysitetrail_options ); ?>
	
	<?php settings_fields( 'themesbysitetrail_theme_options' );
	/* This function outputs some hidden fields required by the form,
	including a nonce, a unique number used to ensure the form has been submitted from the admin page
	and not somewhere else, very important for security */ ?>

	<table class="form-table"><!-- Grab a hot cup of coffee, yes we're using tables! -->

	<tr valign="top"><td></td><th scope="row"><label for="featured_cat">Featured Category</label></th>
	<td>
	<select id="featured_cat" name="themesbysitetrail_options[featured_cat]">
	<?php
	foreach ( $themesbysitetrail_categories as $category ) :
		echo '<option style="padding-right: 10px;" value="' . esc_attr( $category['value'] ) . '" '; if(isset($settings['featured_cat'])){selected( $settings['featured_cat'], $category['value'] );} echo '>' . $category['label'] . '</option>';
	endforeach;
	?>
	</select>
	</td>
	</tr>
    
    <tr valign="top"><td></td><th scope="row"><label for="ad_count">Number of Ads</label></th>
	<td>
	<select id="ad_count" name="themesbysitetrail_options[ad_count]">
	<?php
	for ($i=0; $i<=4; $i++) :
		echo '<option style="padding-right: 10px;" value="' . esc_attr( $i ) . '" '; if(isset($settings['ad_count'])){selected( $settings['ad_count'], $i);} echo '>' . $i . '</option>';
	endfor;
	?>
	</select>
	</td>
	</tr>
    
	<tr valign="top"><td style="text-align: right;"><?php if(isset($settings['ad125x125_img1'])){ ?><img src="<?php esc_attr_e($settings['ad125x125_img1']); ?>" alt="" /><?php } ?></td><th scope="row"><label for="ad125x125_img1">125 x 125 pixel banner A (upper left adbox) IMAGE url</label></th>
	<td>
	<input id="ad125x125_img1" name="themesbysitetrail_options[ad125x125_img1]" type="text" size="75"value="<?php  if(isset($settings['ad125x125_img1']))esc_attr_e($settings['ad125x125_img1']); ?>" />
    <small style="display: block; width: 500px;">Note: Please input the image url of banner A (upper left adbox). <em>eg: http://website.com/image.jpg.</em> Leave blank if you want to use default image.</small>
	</td>
	</tr>
    
    <tr valign="top"><td></td><th scope="row"><label for="ad125x125_link1">125 x 125 pixel banner A (upper left adbox) ADVERTISER url</label></th>
	<td>
	<input id="ad125x125_link1" name="themesbysitetrail_options[ad125x125_link1]" type="text" size="75"value="<?php  if(isset($settings['ad125x125_link1']))esc_attr_e($settings['ad125x125_link1']); ?>" />
    <small style="display: block; width: 500px;">Note: Please input the advertiser's url of banner A (upper left adbox). <em>eg: http://website.com/image.jpg.</em> If you're still looking for advertisers, please paste your advertisement info page url.</small>
	</td>
	</tr>
   
	<tr valign="top"><td style="text-align: right;"><?php if(isset($settings['ad125x125_img2'])){ ?><img src="<?php esc_attr_e($settings['ad125x125_img2']); ?>" alt="" /><?php } ?></td><th scope="row"><label for="ad125x125_img2">125 x 125 pixel banner B (upper right adbox) IMAGE url</label></th>
	<td>
	<input id="ad125x125_img2" name="themesbysitetrail_options[ad125x125_img2]" type="text" size="75"value="<?php  if(isset($settings['ad125x125_img2']))esc_attr_e($settings['ad125x125_img2']); ?>" />
    <small style="display: block; width: 500px;">Note: Please input the image url of banner B (upper right adbox). <em>eg: http://website.com/image.jpg.</em> Leave blank if you want to use default image.</small>
	</td>
	</tr>
    
    <tr valign="top"><td></td><th scope="row"><label for="ad125x125_link2">125 x 125 pixel banner B (upper right adbox) ADVERTISER url<br /></label></th>
	<td>
	<input id="ad125x125_link2" name="themesbysitetrail_options[ad125x125_link2]" type="text" size="75"value="<?php  if(isset($settings['ad125x125_link2']))esc_attr_e($settings['ad125x125_link2']); ?>" />
    <small style="display: block; width: 500px;">Note: Please input the advertiser's url of banner B (upper right adbox). <em>eg: http://website.com/image.jpg.</em> If you're still looking for advertisers, please paste your advertisement info page url.</small>
	</td>
	</tr>
    
	<tr valign="top"><td style="text-align: right;"><?php if(isset($settings['ad125x125_img3'])){ ?><img src="<?php esc_attr_e($settings['ad125x125_img3']); ?>" alt="" /><?php } ?></td><th scope="row"><label for="ad125x125_img3">125 x 125 pixel banner C (lower left adbox) IMAGE url</label></th>
	<td>
	<input id="ad125x125_img3" name="themesbysitetrail_options[ad125x125_img3]" type="text" size="75"value="<?php  if(isset($settings['ad125x125_img3']))esc_attr_e($settings['ad125x125_img3']); ?>" />
    <small style="display: block; width: 500px;">Note: Please input the image url of banner C (lower left adbox). <em>eg: http://website.com/image.jpg.</em> Leave blank if you want to use default image.</small>
	</td>
	</tr>
    
    <tr valign="top"><td></td><th scope="row"><label for="ad125x125_link3">125 x 125 pixel banner C (lower left adbox) ADVERTISER url<br /></label></th>
	<td>
	<input id="ad125x125_link3" name="themesbysitetrail_options[ad125x125_link3]" type="text" size="75"value="<?php  if(isset($settings['ad125x125_link2']))esc_attr_e($settings['ad125x125_link2']); ?>" />
    <small style="display: block; width: 500px;">Note: Please input the advertiser's url of banner C (lower left adbox). <em>eg: http://website.com/image.jpg.</em> If you're still looking for advertisers, please paste your advertisement info page url.</small>
	</td>
	</tr>
    
	<tr valign="top"><td style="text-align: right;"><?php if(isset($settings['ad125x125_img4'])){ ?><img src="<?php esc_attr_e($settings['ad125x125_img4']); ?>" alt="" /><?php } ?></td><th scope="row"><label for="ad125x125_img4">125 x 125 pixel banner D (lower right adbox) IMAGE url</label></th>
	<td>
	<input id="ad125x125_img4" name="themesbysitetrail_options[ad125x125_img4]" type="text" size="75"value="<?php  if(isset($settings['ad125x125_img4']))esc_attr_e($settings['ad125x125_img4']); ?>" />
    <small style="display: block; width: 500px;">Note: Please input the image url of banner D (lower right adbox). <em>eg: http://website.com/image.jpg.</em> Leave blank if you want to use default image.</small>
	</td>
	</tr>
    
    <tr valign="top"><td></td><th scope="row"><label for="ad125x125_link4">125 x 125 pixel banner D (lower right adbox) ADVERTISER url<br /></label></th>
	<td>
	<input id="ad125x125_link4" name="themesbysitetrail_options[ad125x125_link4]" type="text" size="75"value="<?php  if(isset($settings['ad125x125_link2']))esc_attr_e($settings['ad125x125_link2']); ?>" />
    <small style="display: block; width: 500px;">Note: Please input the advertiser's url of banner D (lower right adbox). <em>eg: http://website.com/image.jpg.</em> If you're still looking for advertisers, please paste your advertisement info page url.</small>
	</td>
	</tr>
    
	<tr valign="top"><td></td><th scope="row"><label for="footer_copyright">Footer Text</label></th>
	<td>
    <textarea id="footer_copyright" name="themesbysitetrail_options[footer_copyright]" rows="5" cols="63"><?php if(isset($settings['footer_copyright']))echo stripslashes($settings['footer_copyright']); ?></textarea>
    <small style="display: block; width: 500px;">Note: Please type your footer text or whatever you to include in the footer. HTML is allowed.</small>
	</td>
	</tr>

	</table>

	<p class="submit"><input type="submit" class="button-primary" value="Save Options" /></p>

	</form>

	</div>

	<?php
}

function themesbysitetrail_validate_options( $input ) {
	global $themesbysitetrail_options, $themesbysitetrail_categories, $themesbysitetrail_layouts, $allowedposttags;

	$settings = get_option( 'themesbysitetrail_options', $themesbysitetrail_options );
	
	// We select the previous value of the field, to restore it in case an invalid entry has been given
	$prev = $settings['featured_cat'];
	// We verify if the given value exists in the categories array
	if ( !array_key_exists( $input['featured_cat'], $themesbysitetrail_categories ) )
		$input['featured_cat'] = $prev;
	
	$input['footer_copyright'] = wp_kses( $input['footer_copyright'], $allowedposttags );
	
	return $input;
}

endif;  // EndIf is_admin()