<?php

register_sidebar(array('name'=>'sidebar',
	'id'=>'sidebar-1',
	'before_widget' => '<div class="widget">',
	'after_widget' => '</div></div>',
	'before_title' => '<h2><span>',
	'after_title' => '</span></h2><div class="widget2">',
));

register_sidebar(array('name'=>'bottombar',
	'id'=>'bottombar-1',
	'before_widget' => '<div class="widget">',
	'after_widget' => '</div></div>',
	'before_title' => '<h2>',
	'after_title' => '</h2><div class="widget2">',
));	

// This theme uses wp_nav_menu() in one location.
register_nav_menus( array(
	'primary' => 'Primary Navigation',
) );

add_theme_support( 'post-thumbnails', array( 'post' ) ); // Add it for posts
set_post_thumbnail_size( 170, 170, true ); // Normal post thumbnails
add_image_size( 'tabthumb', 50, 50, true ); //  Tab Thumbnails
add_image_size( 'featured', 928, 248, true ); //  Featured image size
add_theme_support('automatic-feed-links');

if (!isset($content_width)) $content_width = 620;

function sitetrail_limit_words($string, $word_limit) {
 
	// creates an array of words from $string (this will be our excerpt)
	// explode divides the excerpt up by using a space character
 
	$words = explode(' ', $string);
 
	// this next bit chops the $words array and sticks it back together
	// starting at the first word '0' and ending at the $word_limit
	// the $word_limit which is passed in the function will be the number
	// of words we want to use
	// implode glues the chopped up array back together using a space character
 
	return implode(' ', array_slice($words, 0, $word_limit));
 
}

function sitetrail_comment($comment, $args, $depth) {
   $GLOBALS['comment'] = $comment; ?>
   <li <?php comment_class(); ?> id="li-comment-<?php comment_ID() ?>">
     <div id="comment-<?php comment_ID(); ?>" class="comment-body">
      <div class="comment-author vcard">
         <?php echo get_avatar($comment,$size='48',$default='<path_to_url>' ); ?>
         <div class="clearer"></div>
      </div>
      <div class="comment-text">
      	  <?php printf('<cite class="fn">%s</cite>', get_comment_author_link()) ?>
		  <?php if ($comment->comment_approved == '0') : ?>
             <em><?php echo 'Your comment is awaiting moderation.'; ?></em>
             <br />
          <?php endif; ?>
    
          <div class="comment-meta commentmetadata"><a href="<?php echo htmlspecialchars( get_comment_link( $comment->comment_ID ) ) ?>"><?php printf('%1$s at %2$s', get_comment_date(),  get_comment_time()) ?></a><?php edit_comment_link('(Edit)','  ','') ?></div>

		  <?php comment_text() ?>
    
          <div class="reply">
             <?php comment_reply_link(array_merge( $args, array('depth' => $depth, 'max_depth' => $args['max_depth']))) ?>
          </div>
     </div>
     <div class="clearer"></div>
     </div>
<?php
        }

require_once ( get_stylesheet_directory() . '/theme-options.php' );


?>