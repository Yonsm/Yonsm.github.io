<div class="tabber">   
     <div class="tabbertab">
     	<h2 class="tabh2"><span>Recent</span></h2>
        <div class="tablist">
            <ul>
            <?php
			wp_reset_query();
			$myposts = get_posts('numberposts=5&offset=1');
            foreach($myposts as $post) :
			setup_postdata($post); ?>
            <li>
            <a href="<?php the_permalink(); ?>"><?php $thumb = the_post_thumbnail( 'tabthumb' ); echo $thumb; ?></a>
            <div class="<?php if(empty($thumb)) echo 'postinfo0'; else echo 'postinfo'; ?>">
            	<a class="hd" href="<?php the_permalink(); ?>"><?php the_title();?></a>
                <div class="tabinfo">
                	<?php the_time('D'); ?> <?php the_time('jS M Y'); ?>
                    <div class="tabxerpt">
                    <?php echo sitetrail_limit_words(get_the_excerpt(), '10'); ?>...
                    </div>
                </div>
            </div>
            <div class="clearer"></div>
            </li>
            <?php endforeach; ?>
            </ul>
        </div>
     </div>
     
     <div class="tabbertab">
        <h2 class="tabh2"><span>Popular</span></h2>
        <div class="tablist">
        <ul>
        <?php $popular = new WP_Query('orderby=comment_count&posts_per_page=5'); ?>
        <?php while ($popular->have_posts()) : $popular->the_post(); ?>                
        <li>
        <a href="<?php the_permalink(); ?>"><?php $thumb = the_post_thumbnail( 'tabthumb' ); echo $thumb; ?></a>
        <div class="<?php if(empty($thumb)) echo 'postinfo0'; else echo 'postinfo'; ?>">
            <a class="hd" href="<?php the_permalink(); ?>"><?php the_title();?></a>
            <div class="tabinfo">
                <?php the_time('D'); ?> <?php the_time('jS M Y'); ?>
                <div class="tabxerpt">
                <?php echo sitetrail_limit_words(get_the_excerpt(), '10'); ?>...
                </div>
            </div>
        </div>
        <div class="clearer"></div>
        </li>          
        <?php endwhile; ?>
        </ul>
        </div>
     </div>

     <div class="tabbertab">
        <h2 class="tabh2"><span>Replies</span></h2>
        <div class="tablist">
            <?php get_template_part("recentcomments") ?>
        </div>
     </div>

</div>