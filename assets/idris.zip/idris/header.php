<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
<html xmlns="http://www.w3.org/1999/xhtml" <?php language_attributes(); ?>>

<head profile="http://gmpg.org/xfn/11">
<meta http-equiv="Content-Type" content="<?php bloginfo('html_type'); ?>; charset=<?php bloginfo('charset'); ?>" />

<title><?php wp_title('&laquo;', true, 'right'); ?> <?php bloginfo('name'); ?><?php $blog_subtitle = get_bloginfo('description'); if(!empty($blog_subtitle)) echo ' - '.$blog_subtitle; ?></title>

<link rel="stylesheet" href="<?php bloginfo('stylesheet_url'); ?>" type="text/css" media="screen" />
<link rel="pingback" href="<?php bloginfo('pingback_url'); ?>" />
<?php if ( is_singular() ) wp_enqueue_script( 'comment-reply' ); ?>
<!--[if lte IE 6]>
<link rel="stylesheet" href="<?php echo get_template_directory_uri(); ?>/css/ie6.css" type="text/css" media="screen" />
<![endif]-->
<!--[if lte IE 7]>
<link rel="stylesheet" href="<?php echo get_template_directory_uri(); ?>/css/ie7.css" type="text/css" media="screen" />
<![endif]-->
<!--[if lte IE 8]>
<link rel="stylesheet" href="<?php echo get_template_directory_uri(); ?>/css/ie8.css" type="text/css" media="screen" />
<![endif]-->
<script type="text/javascript" src="<?php echo get_template_directory_uri(); ?>/js/jquery.js"></script>
<script type="text/javascript" src="<?php echo get_template_directory_uri(); ?>/js/s3Slider.js"></script>
<script type="text/javascript" src="<?php echo get_template_directory_uri(); ?>/js/tabber.js"></script>
<script type="text/javascript">
$(document).ready(function() {
$('#slider').s3Slider({
timeOut: 6000
});
$('.right').s3Slider({
timeOut: 6000
});
});
</script>
<script type="text/javascript">
<![CDATA[//><!--
sfHover = function() {
var sfEls = document.getElementById("nav").getElementsByTagName("LI");
for (var i=0; i<sfEls.length; i++) {
sfEls[i].onmouseover=function() {
this.className+=" sfhover";
}
sfEls[i].onmouseout=function() {
this.className=this.className.replace(new RegExp(" sfhover\\b"), "");
}
}
}
if (window.attachEvent) window.attachEvent("onload", sfHover);
//--><!]]>
</script>
<?php wp_head(); ?>
</head>
<body id="<?php if( is_home() ) : ?>home<?php else : ?>nothome<?php endif; ?>" <?php body_class(); ?>>
<div id="layout">
    <div align="center" style="overflow: hidden;">
        <!-- start Header -->
        <div id="header">
            <div class="headiv">
                <!-- start Topnav -->
                <div id="topnav">              
                    <div id="blogname">
                        <div id="blogname2">
                        <a title="<?php echo bloginfo('name'); ?>" href="<?php echo home_url(); ?>/"><img src="<?php echo get_template_directory_uri(); ?>/images/logo.gif" title="<?php echo bloginfo('name'); ?>" id="logo" /></a>
                        </div>
                    </div>
                    <div id="pages">
                    	<div id="pages2">
                        	<ul> 
                            <li class="home"><a href="<?php echo home_url(); ?>/">Home</a></li>
                            </ul>	
                            <?php wp_nav_menu( array( 'container_class' => 'menu-header', 'theme_location' => 'primary' ) ); ?>                  
                        </div>
                    </div>
                    <div class="clearer"></div>                  
                </div>
                <!-- end Top Nav -->
            </div>
        </div>
        <!-- end Header -->
		<?php if(is_home() && !is_paged()): ?>
        <?php // Featured posts go here.
        get_template_part("featured"); ?>
        <?php endif;?>                                   
        <!-- start Wrapper -->
        <div id="wrapper">
           <div id="container"> 