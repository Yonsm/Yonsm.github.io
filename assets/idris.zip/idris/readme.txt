=== Idris ===
Author: SiteTrail
Tags: two-columns, fixed-width, custom-header, custom-background, threaded-comments, theme-options, right-sidebar
Tested up to: WP 3.2

An elegant highly customizable theme.

== Description ==

An elegant, modern and professional theme built with simplicity in mind. This web 2.0 theme is highly customizable and flexible enough to use in any industry.

== Installation ==

You can install the theme through the WordPress installer under <strong>Themes &rarr; Install themes</strong> by searching for it.
Alternatively you can download the file from here, unzip it and move the unzipped contents to the <code>wp-content/themes</code> folder
of your WordPress installation. You will then be able to activate the theme.

== Limitation ==

Menus with a large number of items have trouble displaying fully on 1024x768 screen resolution.