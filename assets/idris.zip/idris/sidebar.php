       <!-- start Sidebar -->
        <div id="sidebar">
            <!-- start search -->
            <div id="topsearch">
            <?php get_search_form(); ?>
            </div>
            <!-- end search -->        
			<?php // Advertisement Boxes (125 x 125 pixels)... (Edit in ad125x125.php)
            get_template_part("ad125x125"); ?>            
            <?php // The Tabs in Sidebar...
            get_template_part("tabs"); ?>                                                                                       
            <?php 	/* Widgetized sidebar, if you have the plugin installed. */
                if ( !function_exists('dynamic_sidebar') || !dynamic_sidebar('sidebar') ) : ?>
            <div class="widget">
                <h2>Notice!</h2>
                <div class="widget2">Please enable widgets in sidebar!</div>
            </div>
            <?php  ?>
            <?php endif; ?> 
        </div>
        <!-- end Sidebar -->