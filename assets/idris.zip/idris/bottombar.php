    <!-- start Bottombar -->
    <div id="bottom">
    	<div id="bottom2">
            <div id="bottombar">
            <?php 	/* Widgetized sidebar, if you have the plugin installed. */
                if ( !function_exists('dynamic_sidebar') || !dynamic_sidebar('bottombar') ) : ?>
            <div class="widget">
                <h2>Notice!</h2>
                <div class="widget2">Please enable widgets in bottombar!</div>
            </div>
            <?php  ?>
            <?php endif; ?>
            <div class="clearer"></div>
            </div>
        </div>
    </div>
    <!-- end Bottombar -->