<?php
global $themesbysitetrail_options;
$themesbysitetrail_settings = get_option( 'themesbysitetrail_options', $themesbysitetrail_options );
?>
<!-- Start Featured Post Carousel -->
<div id="<?php if($themesbysitetrail_settings['featured_cat']) echo'featured'; else echo 'featured0'; ?>">
    <div id="featured2">
        <div id="slider">
            <ul id="sliderContent">
            	<?php if( $themesbysitetrail_settings['featured_cat'] ) : ?>
                <?php query_posts('cat=' . $themesbysitetrail_settings['featured_cat'] ); ?>
                <?php while (have_posts()) : the_post(); ?>
                <li class="sliderImage">
                  <a href="<?php the_permalink() ?>" rel="bookmark" title="Permanent Link to <?php the_title(); ?>"><?php the_post_thumbnail('featured'); ?></a>
                  <a class="blankfa" href="<?php the_permalink() ?>" rel="bookmark" title="Continue reading <?php the_title(); ?>">&nbsp;</a>
                <span class="left ftext">
                    <strong class="ftitle"><a href="<?php the_permalink() ?>" rel="bookmark" title="Continue reading <?php the_title(); ?>"><?php the_title(); ?></a></strong>                 
                    <strong class="ftext2"><?php echo sitetrail_limit_words(get_the_excerpt(), '20'); ?>.</strong>
                    <strong class="fentryinfo">
                    <a href="<?php the_permalink() ?>" rel="bookmark" title="Continue reading <?php the_title(); ?>" class="freadmore">Read More &raquo;</a>
                    
                    <em><?php the_time('jS F Y') ?></em>
                    </strong>                    
                </span>
                </li>
                <?php endwhile; ?>
                <?php endif; ?>
                <li class="sliderImage">
                
                <a href=""></a>
                
                <span class="bottom">
                <strong class="etitle"><a href=""></a></strong>
                </span>
                </li>
            </ul>
        </div>
    </div>
</div>
<!-- End Featured Post Carousel -->