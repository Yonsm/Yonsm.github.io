                <div class="clearer"></div>
            </div>
        </div>
        <!-- end wrapper -->
        
        <?php get_template_part("bottombar"); ?>
        
        <!-- start Footer -->
        <div id="footer">
            <div id="footerw">
                <div id="fl">
                        <?php wp_nav_menu( array( 'container_class' => 'menu-header', 'theme_location' => 'primary' ) ); ?> 
                </div>
                <div id="fr">
                <?php
				global $themesbysitetrail_options;
				$themesbysitetrail_settings = get_option( 'themesbysitetrail_options', $themesbysitetrail_options );
				?>
                <?php if(!empty($themesbysitetrail_settings['footer_copyright']))echo $themesbysitetrail_settings['footer_copyright'];else echo $themesbysitetrail_options['footer_copyright']; ?> Designed by <a href="http://www.sitetrail.com" target="_blank">SiteTrail</a>.
                </div>
                <div class="clearer"></div>
            </div>
        </div>
        <!-- end Footer -->    
    </div>
</div>
<?php wp_footer(); ?>
</body>
</html>

