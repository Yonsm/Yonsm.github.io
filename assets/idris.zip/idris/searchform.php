<form method="get" id="searchform" action="<?php echo home_url(); ?>/">
<input type="text" value="<?php the_search_query(); ?>" name="s" id="s" /><input type="image" src="<?php echo get_template_directory_uri(); ?>/images/searchsubmit.gif" alt="Search" id="searchsubmit" />
<div class="clearer"></div>
</form>
