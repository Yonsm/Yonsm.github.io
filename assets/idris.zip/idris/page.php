<?php get_header(); ?>

<div id="content">
    <div id="entries">
        <div id="entries2">
			<?php if (have_posts()) : while (have_posts()) : the_post(); ?>
            <div class="post si" id="post-<?php the_ID(); ?>">
                <div class="entry">
                    <div class="entryinfo">
                        <h2><?php the_title(); ?></h2>
                    </div>
                    
					<?php the_content('<p class="serif">Read the rest of this page &raquo;</p>'); ?>
            
                    <?php wp_link_pages(array('before' => '<p><strong>Pages:</strong> ', 'after' => '</p>', 'next_or_number' => 'number')); ?>
            
                    <?php edit_post_link('Edit this entry.', '<p>', '</p>'); ?>
                 </div>
                 <div id="commentsarea">
                    <?php comments_template(); ?>
                 </div>
            </div>
            <?php endwhile; endif; ?>
		</div>
    </div>
</div>

<?php get_sidebar(); ?>

<?php get_footer(); ?>