//{{NO_DEPENDENCIES}}
// Microsoft Visual C++ generated include file.
// Used by Resource.rc
//
#define IDI_Main                        100
#define IDI_File                        101
#define IDD_Main                        200
#define IDC_Path                        300
#define IDC_Browse                      303
#define IDC_Brand                       304
#define IDC_Log                         305
#define IDS_Filter                      500
#define IDS_AppName                     506
#define IDS_Assoc                       512
#define IDS_UnAssoc                     513
#define IDC_About                       515
#define IDC_Logo                        516
#define IDS_FoundDevice                 600
#define IDS_FoundDriver                 601
#define IDD_Dialog                      10015
#define IDC_Cmd                         30104

// Next default values for new objects
// 
#ifdef APSTUDIO_INVOKED
#ifndef APSTUDIO_READONLY_SYMBOLS
#define _APS_NO_MFC                     1
#define _APS_NEXT_RESOURCE_VALUE        10016
#define _APS_NEXT_COMMAND_VALUE         20122
#define _APS_NEXT_CONTROL_VALUE         30105
#define _APS_NEXT_SYMED_VALUE           40007
#endif
#endif
